#ifndef HUMAN_H
#define HUMAN_H
using namespace std;
class Human{
	public:
		string cnic;
		string name;
		int age;
	
	public:
		Human(string cnic, string name, int age);
		void display();		
};

#endif
