#include<iostream>
#include<string>
#include "Human.h"
using namespace std;
Human::Human(string cnic, string name, int age)
{
	this->cnic = cnic;
	this->name = name;
	this->age = age;		
}
void Human::display()
{
	cout<<this->cnic<<this->name<<this->age;	
}
